<template>
  <Play/>
</template>

<script>
import Play from './components/Play.vue'

export default {
  name: 'App',
  components: {
    Play
  }
}
</script>

<style>
*{
  margin: 0;
  padding: 0;
}

#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
</style>
